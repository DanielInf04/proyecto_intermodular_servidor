/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.api.musiclab.repository;

import com.api.musiclab.entities.Usuario;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author danig
 */
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    
    Optional<Usuario> findByGoogleSub(String googleSub);
    boolean existsByGoogleSub(String googleSub);
    
    Optional<Usuario> findByUsername(String username); // -> Después quitar

    Optional<Usuario> findByEmail(String email);
    
    boolean existsByUsername(String username);

    boolean existsByEmail(String email);
    
    Page<Usuario> findByUsernameContainingIgnoreCaseOrEmailContainingIgnoreCase(
            String username,
            String email,
            Pageable pageable
    );
}
